<?php
phpinfo(INFO_ENVIRONMENT);
?>
