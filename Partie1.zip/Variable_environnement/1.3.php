<?php
echo "<table border='1'>";
echo "<tr><th>Variable</th><th>Valeur</th></tr>";
echo "<tr><td>\$SERVER_ADDR</td><td>{$_SERVER['SERVER_ADDR']}</td></tr>";
echo "<tr><td>\$HTTP_HOST</td><td>{$_SERVER['HTTP_HOST']}</td></tr>";
echo "<tr><td>\$REMOTE_ADDR</td><td>{$_SERVER['REMOTE_ADDR']}</td></tr>";
echo "<tr><td>gethostbyAddr (\$REMOTE_ADDR)</td><td>" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . "</td></tr>";
echo "<tr><td>\$HTTP_USER_AGENT</td><td>{$_SERVER['HTTP_USER_AGENT']}</td></tr>";
echo "</table>";
?>
