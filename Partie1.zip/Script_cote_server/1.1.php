<?php
echo "Hello PHP, nous sommes le " . date("Y-m-d");
?>
