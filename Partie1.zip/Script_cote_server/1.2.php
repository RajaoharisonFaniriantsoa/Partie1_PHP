<?php
$heure = date("H");
if ($heure < 12) {
    echo date("Y-m-d") . " Bon matin";
} else {
    echo date("Y-m-d") . " Bonne après-midi";
}
?>
