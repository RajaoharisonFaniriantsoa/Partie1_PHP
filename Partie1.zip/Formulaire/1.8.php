<?php
class Personne {
    
    public $nom;
    public $prenom;

    
    public function __construct($nom, $prenom) {
        $this->nom = $nom;
        $this->prenom = $prenom;
    }

   
    public function presentation() {
        return "Je m'appelle $this->prenom $this->nom.";
    }
}


$personne = new Personne("Doe", "John");
echo $personne->presentation(); 
?>
