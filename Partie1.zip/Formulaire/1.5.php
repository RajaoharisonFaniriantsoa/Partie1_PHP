<!DOCTYPE html>
<html>
<head>
    <title>Traitement du formulaire</title>
</head>
<body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    
    if (isset($_GET['nom']) && isset($_GET['prenom']) && isset($_GET['sexe']) && isset($_GET['vins'])) {
        $nom = $_GET['nom'];
        $prenom = $_GET['prenom'];
        $sexe = $_GET['sexe'];
        $vins = implode(", ", $_GET['vins']); 

       
        echo "<h2>Données soumises :</h2>";
        echo "<p>Nom : $nom</p>";
        echo "<p>Prénom : $prenom</p>";
        echo "<p>Sexe : $sexe</p>";
        echo "<p>Vins sélectionnés : $vins</p>";
    } else {
        echo "<p>Le formulaire n'a pas été soumis ou toutes les données n'ont pas été remplies.</p>";
    }
} else {
    echo "<p>La méthode de requête n'est pas prise en charge.</p>";
}
?>
</body>
</html>
