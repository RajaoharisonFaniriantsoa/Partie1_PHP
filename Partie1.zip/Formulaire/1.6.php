<!DOCTYPE html>
<html>
<head>
    <title>Traitement du formulaire</title>
</head>
<body>
<?php

if (!isset($_GET['form_submitted']) || (empty($_GET['nom']) && empty($_GET['prenom']) && empty($_GET['sexe']) && !isset($_GET['vins']))) {
?>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="GET">
        <label for="nom">Nom:</label>
        <input type="text" id="nom" name="nom" value="<?php echo isset($_GET['nom']) ? $_GET['nom'] : ''; ?>"><br><br>
        <label for="prenom">Prénom:</label>
        <input type="text" id="prenom" name="prenom" value="<?php echo isset($_GET['prenom']) ? $_GET['prenom'] : ''; ?>"><br><br>
        <label for="sexe">Sexe:</label>
        <select id="sexe" name="sexe">
            <option value="M" <?php if(isset($_GET['sexe']) && $_GET['sexe'] == 'M') echo 'selected'; ?>>Masculin</option>
            <option value="F" <?php if(isset($_GET['sexe']) && $_GET['sexe'] == 'F') echo 'selected'; ?>>Féminin</option>
        </select><br><br>
        <label for="vins">Vins:</label>
        <select id="vins" name="vins[]" multiple>
            <option value="Tana" <?php if(isset($_GET['vins']) && in_array('Tana', $_GET['vins'])) echo 'selected'; ?>>Tana</option>
            <option value="Antsirabe" <?php if(isset($_GET['vins']) && in_array('Antsirabe', $_GET['vins'])) echo 'selected'; ?>>Antsirabe</option>
            <option value="Tamatave" <?php if(isset($_GET['vins']) && in_array('Tamatave', $_GET['vins'])) echo 'selected'; ?>>Tamatave</option>
        </select><br><br>
        <input type="hidden" name="form_submitted" value="1">
        <input type="submit" value="Envoyer">
    </form>
<?php
} else {
   
    $nom = isset($_GET["nom"]) ? $_GET["nom"] : "";
    $prenom = isset($_GET["prenom"]) ? $_GET["prenom"] : "";
    $sexe = isset($_GET["sexe"]) ? $_GET["sexe"] : "";
    $vins = isset($_GET["vins"]) ? implode(", ", $_GET["vins"]) : "";

    
    echo "<h2>Données soumises :</h2>";
    echo "<p>Nom : $nom</p>";
    echo "<p>Prénom : $prenom</p>";
    echo "<p>Sexe : $sexe</p>";
    if (!empty($vins)) {
        echo "<p>Vins sélectionnés :</p>";
        echo "<ul>";
        foreach ($_GET["vins"] as $vin) {
            echo "<li>$vin</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Aucun vin sélectionné</p>";
    }
}
?>
</body>
</html>
