<!DOCTYPE html>
<html>
<head>
    <title>Traitement du texte</title>
</head>
<body>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $texte = isset($_POST["texte"]) ? $_POST["texte"] : "";

    
    $texte_formate = nl2br($texte);

    
    echo "<p>Texte saisi :</p>";
    echo "<div>$texte_formate</div>";
}
?>
</body>
</html>
