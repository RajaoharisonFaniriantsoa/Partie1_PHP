<?php
class Personne {

    public $nom;
    public $prenom;
    public $date_naissance;

   
    public function __construct($nom, $prenom, $date_naissance) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->date_naissance = $date_naissance;
    }

    
    public function presentation() {
        return "Je m'appelle $this->prenom $this->nom.";
    }

    
    public function age() {
        $date_naissance = new DateTime($this->date_naissance);
        $maintenant = new DateTime();
        $difference = $date_naissance->diff($maintenant);
        return $difference->y; 
    }
}



$personne1 = new Personne("Doe", "John", "1990-05-15");
$personne2 = new Personne("Smith", "Alice", "1985-10-20");


echo $personne1->presentation() . " Age: " . $personne1->age() . " ans.<br>";
echo $personne2->presentation() . " Age: " . $personne2->age() . " ans.";
?>
