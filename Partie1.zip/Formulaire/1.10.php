<?php
class Personne {
    
    public $nom;
    public $prenom;
    public $date_naissance;


    public function __construct($nom, $prenom, $date_naissance) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->date_naissance = $date_naissance;
    }


    public function presentation() {
        return "Je m'appelle $this->prenom $this->nom.";
    }

    // Méthode pour calculer l'âge de la personne
    public function age() {
        $date_naissance = new DateTime($this->date_naissance);
        $maintenant = new DateTime();
        $difference = $date_naissance->diff($maintenant);
        return $difference->y; 
    }
}


$personne = new Personne("Doe", "John", "1990-05-15");
echo $personne->presentation() . "<br>";
echo "Age: " . $personne->age() . " ans.";
?>
